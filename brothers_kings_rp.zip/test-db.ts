import * as db from "./server/db";

async function test() {
  try {
    console.log("Testing database connection...");
    const categories = await db.getCategories();
    console.log("✅ Categories loaded:", categories.length);
    categories.forEach((cat) => {
      console.log(`  - ${cat.nameAr} (ID: ${cat.id})`);
    });

    if (categories.length > 0) {
      const laws = await db.getLawsByCategory(categories[0].id);
      console.log(`✅ Laws for ${categories[0].nameAr}:`, laws.length);
      laws.forEach((law) => {
        console.log(`  - ${law.titleAr}`);
      });
    }
  } catch (error) {
    console.error("❌ Error:", error);
  }
}

test();
