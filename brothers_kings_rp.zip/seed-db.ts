import { drizzle } from "drizzle-orm/mysql2";
import { categories, laws } from "./drizzle/schema";

const db = drizzle(process.env.DATABASE_URL!);

const seedData = {
  categories: [
    {
      name: "City Laws",
      nameAr: "قوانين المدينة",
      description: "General city regulations and rules",
      descriptionAr: "القوانين العامة للمدينة والقواعد الأساسية",
      icon: "🏛️",
      order: 1,
    },
    {
      name: "Theft Laws",
      nameAr: "قوانين السرقات",
      description: "Laws related to theft and robbery",
      descriptionAr: "القوانين المتعلقة بالسرقة والنهب",
      icon: "🚨",
      order: 2,
    },
    {
      name: "Health Laws",
      nameAr: "قوانين الصحة",
      description: "Health and safety regulations",
      descriptionAr: "قوانين الصحة والسلامة العامة",
      icon: "⚕️",
      order: 3,
    },
    {
      name: "Police Laws",
      nameAr: "قوانين الشرطة",
      description: "Police department regulations",
      descriptionAr: "قوانين وتنظيمات قسم الشرطة",
      icon: "👮",
      order: 4,
    },
    {
      name: "Crime Laws",
      nameAr: "قوانين الإجرام",
      description: "Criminal offense regulations",
      descriptionAr: "قوانين الجرائم والمخالفات الجنائية",
      icon: "⚖️",
      order: 5,
    },
    {
      name: "Store Laws",
      nameAr: "قوانين المتجر",
      description: "Store and business regulations",
      descriptionAr: "قوانين المتاجر والأعمال التجارية",
      icon: "🏪",
      order: 6,
    },
    {
      name: "Ticket Laws",
      nameAr: "قوانين التكت",
      description: "Traffic and ticket regulations",
      descriptionAr: "قوانين المخالفات والتذاكر المرورية",
      icon: "🎫",
      order: 7,
    },
    {
      name: "Admin Laws",
      nameAr: "قوانين الإدارة",
      description: "Administrative rules and procedures",
      descriptionAr: "قوانين وإجراءات الإدارة",
      icon: "⚙️",
      order: 8,
    },
  ],
  laws: [
    // City Laws
    {
      categoryId: 1,
      title: "Speed Limit",
      titleAr: "حد السرعة",
      description: "Do not exceed speed limits in city areas",
      descriptionAr: "عدم تجاوز حدود السرعة في مناطق المدينة",
      penalty: "Fine $500 or jail time",
      penaltyAr: "غرامة 500 دولار أو السجن",
      severity: "medium" as const,
      order: 1,
    },
    {
      categoryId: 1,
      title: "No Parking",
      titleAr: "عدم الوقوف",
      description: "Do not park in restricted areas",
      descriptionAr: "عدم الوقوف في المناطق المحظورة",
      penalty: "Fine $250",
      penaltyAr: "غرامة 250 دولار",
      severity: "low" as const,
      order: 2,
    },
    // Theft Laws
    {
      categoryId: 2,
      title: "Vehicle Theft",
      titleAr: "سرقة المركبات",
      description: "Stealing vehicles is a serious crime",
      descriptionAr: "سرقة المركبات جريمة خطيرة جداً",
      penalty: "Prison 30 minutes or fine $2000",
      penaltyAr: "السجن 30 دقيقة أو غرامة 2000 دولار",
      severity: "high" as const,
      order: 1,
    },
    {
      categoryId: 2,
      title: "Store Robbery",
      titleAr: "سرقة المتجر",
      description: "Robbing stores is forbidden",
      descriptionAr: "سرقة المتاجر محظورة تماماً",
      penalty: "Prison 45 minutes or fine $3000",
      penaltyAr: "السجن 45 دقيقة أو غرامة 3000 دولار",
      severity: "critical" as const,
      order: 2,
    },
    // Health Laws
    {
      categoryId: 3,
      title: "No Weapons in Hospital",
      titleAr: "عدم حمل الأسلحة في المستشفى",
      description: "Weapons are not allowed in hospital zones",
      descriptionAr: "الأسلحة غير مسموحة في مناطق المستشفى",
      penalty: "Fine $1000 and weapon confiscation",
      penaltyAr: "غرامة 1000 دولار ومصادرة السلاح",
      severity: "high" as const,
      order: 1,
    },
    // Police Laws
    {
      categoryId: 4,
      title: "Obey Police Orders",
      titleAr: "الامتثال لأوامر الشرطة",
      description: "Always obey police officer commands",
      descriptionAr: "يجب الامتثال دائماً لأوامر ضابط الشرطة",
      penalty: "Prison 15 minutes",
      penaltyAr: "السجن 15 دقيقة",
      severity: "medium" as const,
      order: 1,
    },
    // Crime Laws
    {
      categoryId: 5,
      title: "Murder",
      titleAr: "القتل",
      description: "Murder is the most serious crime",
      descriptionAr: "القتل هو أخطر جريمة",
      penalty: "Prison 60 minutes",
      penaltyAr: "السجن 60 دقيقة",
      severity: "critical" as const,
      order: 1,
    },
    // Store Laws
    {
      categoryId: 6,
      title: "Business Hours",
      titleAr: "ساعات العمل",
      description: "Stores must close at specified times",
      descriptionAr: "يجب إغلاق المتاجر في الأوقات المحددة",
      penalty: "Fine $500",
      penaltyAr: "غرامة 500 دولار",
      severity: "low" as const,
      order: 1,
    },
    // Ticket Laws
    {
      categoryId: 7,
      title: "Traffic Violation",
      titleAr: "مخالفة مرورية",
      description: "Traffic violations will result in tickets",
      descriptionAr: "المخالفات المرورية تؤدي إلى تذاكر",
      penalty: "Fine $300",
      penaltyAr: "غرامة 300 دولار",
      severity: "low" as const,
      order: 1,
    },
    // Admin Laws
    {
      categoryId: 8,
      title: "Admin Commands",
      titleAr: "أوامر الإدارة",
      description: "Admin commands are for authorized personnel only",
      descriptionAr: "أوامر الإدارة للموظفين المصرح لهم فقط",
      penalty: "Ban from server",
      penaltyAr: "حظر من السيرفر",
      severity: "critical" as const,
      order: 1,
    },
  ],
};

async function seed() {
  try {
    console.log("🌱 Starting database seed...");

    // Insert categories
    console.log("📝 Inserting categories...");
    for (const category of seedData.categories) {
      await db.insert(categories).values(category);
    }
    console.log(`✅ Inserted ${seedData.categories.length} categories`);

    // Insert laws
    console.log("📝 Inserting laws...");
    for (const law of seedData.laws) {
      await db.insert(laws).values(law);
    }
    console.log(`✅ Inserted ${seedData.laws.length} laws`);

    console.log("🎉 Database seeding completed successfully!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    process.exit(1);
  }
}

seed();
