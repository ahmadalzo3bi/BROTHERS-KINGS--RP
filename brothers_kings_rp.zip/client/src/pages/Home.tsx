import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Edit2, Trash2 } from "lucide-react";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);

  // Fetch categories
  const categoriesQuery = trpc.laws.getCategories.useQuery(undefined, {
    staleTime: Infinity,
  });
  const categories = categoriesQuery.data || [];

  // Fetch laws for selected category
  const lawsQuery = trpc.laws.getLawsByCategory.useQuery(
    { categoryId: selectedCategory || 0 },
    { enabled: selectedCategory !== null && selectedCategory !== 0 }
  );
  const laws = lawsQuery.data || [];

  // Set default category on load
  useEffect(() => {
    if (categories && categories.length > 0 && selectedCategory === null) {
      setSelectedCategory(categories[0].id);
    }
  }, [categories, selectedCategory]);

  const categoryIcons: Record<string, string> = {
    "قوانين المدينة": "🏛️",
    "قوانين السرقات": "🚨",
    "قوانين الصحة": "⚕️",
    "قوانين الشرطة": "👮",
    "قوانين الإجرام": "⚖️",
    "قوانين المتجر": "🏪",
    "قوانين التكت": "🎫",
    "قوانين الإدارة": "⚙️",
  };

  const severityColors: Record<string, string> = {
    low: "bg-blue-100 text-blue-800",
    medium: "bg-yellow-100 text-yellow-800",
    high: "bg-orange-100 text-orange-800",
    critical: "bg-red-100 text-red-800",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-red-950 to-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-black/80 backdrop-blur-md border-b-2 border-red-600">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-red-800 rounded-lg flex items-center justify-center font-bold text-lg">
                BK
              </div>
              <div>
                <h1 className="text-2xl font-bold text-red-500">BROTHERS KINGS RP</h1>
                <p className="text-xs text-gray-400">Server Rules & Laws</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Categories */}
          <aside className="lg:col-span-1">
            <div className="bg-black/50 border border-red-600/30 rounded-lg p-6 sticky top-24">
              <h2 className="text-xl font-bold text-red-500 mb-4">الفئات</h2>
              <div className="space-y-2">
                {categories.map((category: any) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full text-right px-4 py-3 rounded-lg transition-all duration-200 ${
                      selectedCategory === category.id
                        ? "bg-gradient-to-r from-red-600 to-red-700 text-white border border-red-400"
                        : "bg-gray-900/50 text-gray-300 hover:bg-gray-800 border border-gray-700"
                    }`}
                  >
                    <span className="inline-block ml-2">
                      {categoryIcons[category.nameAr] || "📋"}
                    </span>
                    {category.nameAr}
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* Main Content Area */}
          <div className="lg:col-span-3">
            {selectedCategory !== null && selectedCategory !== 0 && (
              <div>
                {/* Category Header */}
                <div className="mb-8">
                  <div className="bg-gradient-to-r from-red-600 to-red-700 rounded-lg p-8 border border-red-500/50">
                    <h2 className="text-3xl font-bold mb-2">
                      {categories.find((c: any) => c.id === selectedCategory)?.nameAr}
                    </h2>
                    <p className="text-red-100">
                      {categories.find((c: any) => c.id === selectedCategory)?.descriptionAr}
                    </p>
                  </div>
                </div>

                {/* Laws Grid */}
                <div className="space-y-4">
                  {laws.length > 0 ? (
                    laws.map((law: any) => (
                      <div
                        key={law.id}
                        className="bg-black/50 border border-red-600/30 rounded-lg p-6 hover:border-red-500 transition-all duration-200 hover:shadow-lg hover:shadow-red-600/20"
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-xl font-bold text-red-400">
                                {law.titleAr}
                              </h3>
                              {law.severity && (
                                <span
                                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                                    severityColors[law.severity] || severityColors.medium
                                  }`}
                                >
                                  {law.severity === "low"
                                    ? "منخفضة"
                                    : law.severity === "medium"
                                    ? "متوسطة"
                                    : law.severity === "high"
                                    ? "عالية"
                                    : "حرجة"}
                                </span>
                              )}
                            </div>
                            <p className="text-gray-300 mb-3">{law.descriptionAr}</p>
                            {law.penaltyAr && (
                              <div className="bg-red-900/20 border border-red-600/30 rounded p-3">
                                <p className="text-sm text-red-300">
                                  <span className="font-bold">العقوبة:</span> {law.penaltyAr}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-12">
                      <p className="text-gray-400 text-lg">
                        لا توجد قوانين في هذه الفئة حالياً
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-red-600/30 mt-16 py-8 bg-black/50">
        <div className="container mx-auto px-4 text-center text-gray-400">
          <p>© 2024 BROTHERS KINGS RP - جميع الحقوق محفوظة</p>
          <p className="text-sm mt-2">خادم FiveM RP متطور</p>
        </div>
      </footer>
    </div>
  );
}
