import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import * as db from "./db";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  laws: router({
    // Get all categories
    getCategories: publicProcedure.query(async () => {
      return await db.getCategories();
    }),

    // Get laws by category
    getLawsByCategory: publicProcedure
      .input(z.object({ categoryId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLawsByCategory(input.categoryId);
      }),

    // Get all laws
    getAllLaws: publicProcedure.query(async () => {
      return await db.getAllLaws();
    }),

    // Create category (admin only)
    createCategory: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          nameAr: z.string(),
          description: z.string().optional(),
          descriptionAr: z.string().optional(),
          icon: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized");
        }
        return await db.createCategory(input);
      }),

    // Create law (admin only)
    createLaw: protectedProcedure
      .input(
        z.object({
          categoryId: z.number(),
          title: z.string(),
          titleAr: z.string(),
          description: z.string(),
          descriptionAr: z.string(),
          penalty: z.string().optional(),
          penaltyAr: z.string().optional(),
          severity: z.enum(["low", "medium", "high", "critical"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized");
        }
        return await db.createLaw(input);
      }),

    // Update law (admin only)
    updateLaw: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().optional(),
          titleAr: z.string().optional(),
          description: z.string().optional(),
          descriptionAr: z.string().optional(),
          penalty: z.string().optional(),
          penaltyAr: z.string().optional(),
          severity: z.enum(["low", "medium", "high", "critical"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized");
        }
        const { id, ...data } = input;
        return await db.updateLaw(id, data);
      }),

    // Delete law (admin only)
    deleteLaw: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Unauthorized");
        }
        return await db.deleteLaw(input.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
