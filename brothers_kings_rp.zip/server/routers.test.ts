import { describe, it, expect, beforeAll, afterAll } from "vitest";
import * as db from "./db";

describe("Laws Router", () => {
  describe("Categories", () => {
    it("should fetch all categories", async () => {
      const categories = await db.getCategories();
      expect(categories).toBeDefined();
      expect(Array.isArray(categories)).toBe(true);
      expect(categories.length).toBeGreaterThan(0);
    });

    it("should have required category fields", async () => {
      const categories = await db.getCategories();
      const category = categories[0];

      expect(category).toHaveProperty("id");
      expect(category).toHaveProperty("name");
      expect(category).toHaveProperty("nameAr");
      expect(category).toHaveProperty("order");
    });

    it("should have all 8 categories", async () => {
      const categories = await db.getCategories();
      expect(categories.length).toBe(8);
    });

    it("should have correct category names in Arabic", async () => {
      const categories = await db.getCategories();
      const categoryNames = categories.map((c) => c.nameAr);

      expect(categoryNames).toContain("قوانين المدينة");
      expect(categoryNames).toContain("قوانين السرقات");
      expect(categoryNames).toContain("قوانين الصحة");
      expect(categoryNames).toContain("قوانين الشرطة");
      expect(categoryNames).toContain("قوانين الإجرام");
      expect(categoryNames).toContain("قوانين المتجر");
      expect(categoryNames).toContain("قوانين التكت");
      expect(categoryNames).toContain("قوانين الإدارة");
    });
  });

  describe("Laws", () => {
    it("should fetch laws by category", async () => {
      const categories = await db.getCategories();
      const firstCategory = categories[0];

      const laws = await db.getLawsByCategory(firstCategory.id);
      expect(Array.isArray(laws)).toBe(true);
      expect(laws.length).toBeGreaterThan(0);
    });

    it("should have required law fields", async () => {
      const categories = await db.getCategories();
      const laws = await db.getLawsByCategory(categories[0].id);
      const law = laws[0];

      expect(law).toHaveProperty("id");
      expect(law).toHaveProperty("categoryId");
      expect(law).toHaveProperty("title");
      expect(law).toHaveProperty("titleAr");
      expect(law).toHaveProperty("description");
      expect(law).toHaveProperty("descriptionAr");
      expect(law).toHaveProperty("severity");
    });

    it("should filter laws by category correctly", async () => {
      const categories = await db.getCategories();
      const firstCategory = categories[0];

      const laws = await db.getLawsByCategory(firstCategory.id);
      laws.forEach((law) => {
        expect(law.categoryId).toBe(firstCategory.id);
      });
    });

    it("should have valid severity levels", async () => {
      const laws = await db.getAllLaws();
      const validSeverities = ["low", "medium", "high", "critical"];

      laws.forEach((law) => {
        if (law.severity) {
          expect(validSeverities).toContain(law.severity);
        }
      });
    });

    it("should fetch all laws", async () => {
      const laws = await db.getAllLaws();
      expect(Array.isArray(laws)).toBe(true);
      expect(laws.length).toBeGreaterThan(0);
    });

    it("should have at least 10 laws total", async () => {
      const laws = await db.getAllLaws();
      expect(laws.length).toBeGreaterThanOrEqual(10);
    });

    it("should have Arabic titles for all laws", async () => {
      const laws = await db.getAllLaws();
      laws.forEach((law) => {
        expect(law.titleAr).toBeDefined();
        expect(law.titleAr.length).toBeGreaterThan(0);
      });
    });

    it("should have Arabic descriptions for all laws", async () => {
      const laws = await db.getAllLaws();
      laws.forEach((law) => {
        expect(law.descriptionAr).toBeDefined();
        expect(law.descriptionAr.length).toBeGreaterThan(0);
      });
    });
  });

  describe("Data Consistency", () => {
    it("all laws should belong to existing categories", async () => {
      const categories = await db.getCategories();
      const categoryIds = categories.map((c) => c.id);
      const laws = await db.getAllLaws();

      laws.forEach((law) => {
        expect(categoryIds).toContain(law.categoryId);
      });
    });

    it("categories should be ordered correctly", async () => {
      const categories = await db.getCategories();
      for (let i = 0; i < categories.length - 1; i++) {
        expect(categories[i].order).toBeLessThanOrEqual(categories[i + 1].order);
      }
    });
  });
});
